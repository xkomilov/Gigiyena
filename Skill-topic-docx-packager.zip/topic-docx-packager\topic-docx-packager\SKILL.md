---
name: topic-docx-packager
description: Mavzular ro'yxatini saqlagan manba .docx dan har bir mavzu uchun alohida, ilmiy, kamida 800 so'zli, manbali (adabiyotlar bilan) 001.docx...NNN.docx paket tayyorlash. Istalgan soha uchun universal. "paketli mavzular", "röyxat bo'yicha mavzular", "mavzu paketi", "har bir mavzuga alohida docx", "001.docx" so'rovlarida ishlatiladi.
---

# Mavzu paketi → alohida .docx (universal)

Manbadagi mavzular ro'yxatidan har bir mavzu uchun alohida, ilmiy va manbali `.docx` fayl yoziladi (`001.docx`, `002.docx` ...). Matn o'zbek tilida, lotin yozuvida. Asos: `D:\PROMPT\Röyxat böyiça paketli mavzular tayyorlaş.docx`.

Skill fayllari: `C:\Users\xkomilov\.claude\skills\topic-docx-packager\`
- `scripts\read_source.ps1` — manba .docx dan mavzular ro'yxatini o'qiydi
- `scripts\build_docx.js` — JSON spec → NNN.docx (hajm va manba tekshiruvi bilan)
- `scripts\check_outputs.ps1` — natija papkasini mustaqil tekshiradi
- `scripts\kutubxona.py` — sayt kutubxonasi (xayrullokomilov.uz/kutubxona): katalog, tanlash, PDF yuklash, matn ajratish, qidiruv (1.1-bo'lim)
- `references\sources-policy.md` — manba ustuvorligi va tekshirish qoidalari (majburiy o'qing)
- `references\changelog.md` — seans o'zgartirishlari jurnali

## 0. Seans boshida (majburiy — avval so'raladi)

Ishni boshlashdan oldin foydalanuvchidan bitta xabarda so'rang:

1. **Manba** — mavzular ro'yxati saqlangan `.docx` fayl yoki papka yo'li (majburiy).
2. **Natija papkasi** — tayyor `NNN.docx` fayllar yoziladigan papka (majburiy).
3. **Soha / rol** — masalan "epidemiolog, virusolog, immunolog, parazitolog". Berilmasa, manba faylning boshidagi rol tavsifidan olinadi.
4. **Qo'shimcha ma'lumot papkasi** (ixtiyoriy) — kutubxona materiallari (masalan `D:\KUTUBXONA`). Berilmasa faqat internet manbalari ishlatiladi.

Javoblarni `<manba-papkasi>\_build\session.json` ga yozing (`{"source":..., "output":..., "role":..., "library":...}`). Foydalanuvchi berilgan yo'llarni o'zgartirmasdan ishlating; bo'sh joy yoki kirill harflar bo'lsa, yo'lni qo'shtirnoq ichida yuboring.

## 1. Manbani o'qish va rejani ko'rsatish

```
powershell -ExecutionPolicy Bypass -File "C:\Users\xkomilov\.claude\skills\topic-docx-packager\scripts\read_source.ps1" -Path "<manba>"
```

- Mavzular sonini va rejani ko'rsating: raqam, nomi (qanday yozilgan bo'lsa, shunday).
- Raqamlar uzluksizmi, takrorlar bormi — tekshiring. Shubhali bo'lsa, davom etishdan oldin so'rang.
- Fayl nomi tartib raqami bo'yicha: `001.docx` ... `NNN.docx` (uch xonali).
- Manba Word'da ochiq bo'lsa ham o'qiladi.

## 1.1. Sayt kutubxonasi (xayrullokomilov.uz/kutubxona)

Kutubxona sifatida `https://xayrullokomilov.uz/kutubxona` berilsa (umumiy hajmi ~1.9–4.7 GB, 2500+ material), butun kutubxonani yuklamang: ochiq JSON API orqali faqat mavzuga tegishli materiallarni oling. Kirish (login) talab qilinmaydi.

- API: `/api/katalog` (bo'limlar), `/api/materiallar?sahifa=N&q=...` (20 tadan sahifa; `jami` umumiy son), `/api/materiallar/<id>/fayl?yuklab=1` (fayl: PDF, PPTX yoki DOCX).
- Fayllar OCR qilingan: PDF matn qatlami PyMuPDF bilan to'g'ri o'qiladi (kirill matn ham). Poppler yoki tesseract kerak emas.
- Python paketlari: `python3 -m pip install --target <ish>/pylib pymupdf python-docx`, keyin `PYTHONPATH=<ish>/pylib`. Oddiy `pip install` jim muvaffaqiyatsiz bo'lishi mumkin (site-packages yozilmaydi), shuning uchun `--target` ishlating.

Ish tartibi (`<ish>` — masalan `<manba-papkasi>/_build/kutubxona`):

```bash
K=<skill>/scripts/kutubxona.py
python3 $K katalog --work <ish>       # catalog.json: barcha materiallar
python3 $K tanla   --work <ish>       # selected.json: soha regex + bo'lim (standart: parazitologiya/entomologiya)
python3 $K yukla   --work <ish>       # lib/<id>: tanlanganlarni yuklaydi (parazitologiya uchun ~230 fayl, ~530 MB)
python3 $K matn    --work <ish>       # txt/<id>.txt: sahifa belgilari bilan matn, index.json
python3 $K qidir   --work <ish> "гонотроф|gonotrof"   # mavzu bo'yicha: id, nom, sahifalar, parcha
python3 $K qidir-sayt "bezgak"        # saytning o'z qidiruvi (yangi qo'shilgan materiallar uchun)
python3 $K bitta   --work <ish> 1607 2104   # tanlovdan tashqari materialni ID bo'yicha yuklab, txt/ ga qo'shish
```

- Soha boshqa bo'lsa: `tanla --regex "..." --mavzu "<bo'lim nomi>" ...` (bo'lim nomlari `catalog.json` dagi `mavzular[].nomi`).
- Qidiruvda kirill va lotin shaklini birga yozing (`безгак|bezgak`). Natijadagi sahifa raqami — PDF sahifasi (kitobning bosma sahifasi emas).
- Adabiyotlar ro'yxatida kutubxona materiali shunday yoziladi: muallif/tashkilot, nomi, yil (agar faylda bo'lsa) + `xayrullokomilov.uz/kutubxona, material ID <id>`. Muallif yoki yil faylda bo'lmasa, o'ylab topmang.

## 2. Partiyalab ishlash

- Mavzularni **8–10 tadan** partiyalarga bo'ling.
- **Birinchi partiyani** tayyorlab, foydalanuvchiga ko'rsating: fayllar, har birining so'z soni, manbalar soni, tasdiqlanmagan faktlar. Shu yerda so'rang: so'z hisobi qoidasi (sarlavha va adabiyotlar hisobga kirmaydi) to'g'rimi.
- Foydalanuvchi tasdiqlagach, qolgan partiyalarni **mustaqil** oxirigacha bajaring. Har partiyadan keyin `check_outputs.ps1` bilan tekshiring.
- Bir partiyada fayllar yozilgandan keyin tekshiruv natijasini (fayllar soni va formati) qisqa qayd eting.

## 3. Har bir mavzu uchun matn talablari (qat'iy)

- **Til va apostrof**: o'zbekcha, lotin yozuvi. Apostrof faqat oddiy `'` (masalan `o'q`, `g'oya`, `ma'lumot`). Builder boshqa apostroflarni (`’ ʻ ʼ`) avtomatik almashtiradi.
- **Hajm**: asosiy matn kamida **800 so'z**. Sarlavha va "Foydalanilgan adabiyotlar" bo'limi hajmga kirmaydi (taxmin — birinchi partiyada tasdiqlatiladi). Bo'lim sarlavhalari hajmga kiradi. Maksimal chegara yo'q.
- **Sarlavha**: mavzu nomi manbada qanday yozilgan bo'lsa, shunday, raqami bilan (masalan `12.[mavzu nomi]`).
- **Tuzilma**: qisqa **Kirish** → mavzuga mos asosiy bo'limlar (masalan: ta'rif, etiologiya/biologiya, epidemiologiya, klinika, laboratoriya tashxisi, me'yorlar va ko'rsatkichlar, profilaktika, davolash — mavzuga mosini tanlang) → **Xulosa** → **Foydalanilgan adabiyotlar**.
- **Yozish uslubi — esse usulidagi ilmiy maqola** (foydalanuvchi qarori, 2026-11-11; aniqlashtirildi 2026-11-13): batafsil qoidalar 3.1-bo'limda. Qisqasi: izchil abzatslar, ro'yxat minimal, havola abzats oxirida.
- **«Esse» so'zi matnda ishlatilmaydi** (foydalanuvchi qarori, 2026-11-13): matn esse emas, esse usulida yozilgan ilmiy maqola. Matn ichida o'z-o'ziga ishora qilishda «esse», «esseda», «essedagi» o'rniga «mavzu», «mavzuda», «mavzudagi» yoziladi (masalan: «Ushbu mavzuda avval ... ko'rib chiqiladi»).
- **Sanaladigan qismlar**: ro'yxatlar spec'da `{"ul": [...]}` yoki `{"ol": [...]}` ko'rinishida yoziladi. Matnga qo'lda `•` yoki `1.` yozmang.
- **Havolalar**: har bir muhim fakt, raqam va me'yor `[n]` bilan tasdiqlanadi; foydalanuvchi talabi bo'lsa (2026-11-11), havola **abzats oxirida** birlashtirib beriladi: `... [1, 3].` Esse uslubida: izchil abzatslar, ro'yxat minimal. Iqtibos qisqa va tirnoq ichida, manba raqami bilan.
- **Adabiyotlar**: muallif, nom, nashr/tashkilot, yil, DOI/URL (faqat tekshirilgan bo'lsa). Tasdiqlanmagan manba `[tasdiqlanmagan]` deb belgilanadi.
- **Takroriy va o'xshash savollar** (foydalanuvchi qarori, 2026-11-09): har bir savol uchun alohida `.docx` yoziladi (takrorlar birlashtirilmaydi). Bir xil savol (faqat imlo farqi bo'lsa ham) bo'lsa, javob matni ham bir xil yoziladi. O'xshash, lekin boshqa savol bo'lsa, javob savol konteksti (qaysi gijja/bezgak/usul, qaysi jihat so'ralgan)dan kelib chiqib yoziladi. Barcha matnlar qo'lda yoziladi: generator skript yoki kalit-fayl orqali takrorlash ishlatilmaydi.
- **Manba tekshiruvi**: `references\sources-policy.md` qoidalari. Avval kutubxona papkasi (agar berilgan bo'lsa), keyin rasmiy manbalar, keyin xalqaro manbalar. DOI va JSST raqamlari WebSearch/WebFetch orqali tekshiriladi. O'zbekistonga xos raqamlarni tasdiqlay olmasangiz, taxmin qilmang.

## 3.1. Esse usulida ilmiy maqola yozish (sinovdan o'tgan tartib)

Bu tartib 148 ta mavzuda qo'llanib, har bir fayl 800+ so'zga birinchi qurishda yetishi bilan tasdiqlangan.

**Rol**: matn mutaxassis (masalan, parazitologiya bo'yicha oliy toifali shifokor) tilida yoziladi: ravon, mantiqiy bog'langan, asoslantirilgan. Faqat ro'yxat yoki qisqa tezis emas, tushuntiruvchi fikr yuritiladi.

**Tuzilma**:
- Kirish: 2 abzats. Birinchisi mavzuning ta'rifi va ahamiyati, ikkinchisi mavzuning yo'l xaritasi («Ushbu mavzuda ...» bilan boshlanadi, «esse» so'zi ishlatilmaydi) (qaysi masalalar ketma-ket ko'rib chiqilishi).
- Asosiy bo'limlar: 11–12 ta, har biri 2 abzats. Har bir bo'lim bitta aniq masalani yoritadi.
- Mavzuga mos qo'shimcha bo'limlar: kerak bo'lsa "Amaliy ahamiyati", "Differensial tashxis", "Profilaktika", "Manbalar orasidagi farqlar".
- Xulosa: 1 abzats.

## 3.2. Taqiqlangan bo'limlar va iboralar (foydalanuvchi qarori, 2026-11-13)

Matn ilmiy maqola, repetitorlik kursi yoki imtihonga tayyorlov qo'llanmasi emas. Quyidagilar yozilmaydi:
- Bo'limlar: «Tasdiqlanmagan ma'lumotlar» (va uning variantlari), «Laboratoriya xodimi uchun amaliy xulosa», «Laborant uchun ...», «Laborant vazifalari», «Eslatma», «Misol», «Klinik misol», «Tashxis misoli», «Amaliy misol», «Shartli hisoblash misoli», «Takrorlash uchun savollar», «Imtihon uchun qisqa javob», «Savolga javob berish tartibi», «Savolga qanday javob berish mumkin», «Savolga halol javob» hamda shunga o'xshash qisqa, umumiy, kuchsiz bo'limlar.
- Iboralar: «imtihonda ...», «laborant uchun ...», «savolga javob», «bu savolda ...», «savol ... so'raydi», «Savol sarlavhasidagi ...», attestatsiya yoki imtihon savollari ro'yxatiga havola, «esse» so'zi. O'z-o'ziga ishora faqat «Ushbu mavzuda ...», «Mavzu nomidagi ...» shaklida.
- Kirishning yo'l xaritasida «tasdiqlanmagan jihatlar oxirida ko'rsatiladi» kabi va'dalar yozilmaydi.
- Attestatsiya va imtihon savollari ro'yxatlari (test savollari, biletlar) adabiyot manbasi sifatida ishlatilmaydi.
- Haqiqiy, manbadagi hududiy yoki tarixiy faktlar (masalan, Olmaliqdagi holat, Buxoroda rishtaning yo'qotilishi) mazmunli bo'lim bo'lib qolishi mumkin, lekin sarlavhada «misol» so'zi ishlatilmaydi.

Manbada topilmagan yoki tasdiqlanmagan ma'lumot matnga fakt sifatida kirmaydi. Bunday holatlar maqola ichida alohida bo'lim sifatida emas, balki zarur joyda bitta ilmiy izoh bilan («manbalarda keltirilmagan», «manbalar bu masalada farq qiladi») beriladi; to'liq ro'yxati esa `_build/tasdiqlanmagan.md` va yakuniy hisobotda saqlanadi.

**Abzats**: 45–55 so'z, 2–3 gap. Birinchi gap bo'limning asosiy fikrini aytadi, keyingilari sabab, ahamiyat yoki amaliy xulosani ochadi. Abzatslar bir-biriga mantiqan ulanadi ("Shu sababli", "Bunday holatda"). «Bu esa ...» (har qanday shaklda, gap boshida ham, vergul keyin ham) yozilmaydi (foydalanuvchi qarori, 2026-11-17).

**Hajm hisobi**: Kirish + ~12 bo'lim + Xulosa ≈ 13–15 bo'lim bo'lsa, 800–870 so'z chiqadi. 10–11 bo'lim 700–770 so'z beradi, ya'ni yetmaydi. 12 bo'limda ham 780–795 chiqishi mumkin, shuning uchun 13 dan boshlang.

**Havola**: har abzats oxirida bitta birlashgan havola: `... [1, 3].` Gap o'rtasida va ro'yxat bandlari yonida havola qo'yilmaydi. Havola raqamlari `references` ro'yxatiga mos bo'lishi shart.

**Manba bilan ishlash** (qayta yozish rejimida, mavjud qisqa matn asos bo'lsa):
- Asos matndagi faktlar, raqamlar va manbalar saqlanadi, yangi raqam o'ylab topilmaydi.
- Kengaytirishda umumiy tushuntirish, sabab-oqibat va amaliy xulosa qo'shiladi, ammo mavjud manbalarga bog'lanadi.
- Manbada tasdiqlanmagan yoki milliy hujjatlarga mosligi tekshirilmagan fakt matnga kiritilmaydi va `_build/tasdiqlanmagan.md` ga yoziladi (3.2-bo'lim). Taxmin faktdek yozilmaydi.
- Dori dozalari va sxemalari milliy protokol bilan solishtirilmagan bo'lsa, shu qayd etiladi, aniq doza keltirilmaydi.

**Til**:
- Qo'sh tirnoq `"` ishlatilmaydi (JSON buzilishi): faqat `'` va «».
- Apostrof faqat oddiy `'`.
- Uzun tire va ortiqcha bezak yo'q; jumlalar qisqa, fikr aniq.

**Ishlash tartibi (10 tadan partiya)**:
1. Manba matnlarini o'qing (parallel).
2. 13–15 bo'limli specni yozing.
3. Shu turning o'zida quring: `build_docx.js --min 800`. Tur uzilsa tahrirlar yo'qolishi mumkin.
4. `QISQA` chiqsa, `Xulosa` bo'limi oldiga yangi mazmunli bo'lim qo'shing va qayta quring. Quruq so'z to'ldirish emas, haqiqiy mazmun kerak.
5. `check_outputs.ps1 -Expected N` (yoki `check_outputs.py --expected N`) bilan tekshiring va `changelog.md` ga holat yozing. `check_outputs.py` 3.2-bo'limdagi taqiqlangan sarlavha va iboralarni ham XATO deb belgilaydi.

## 3.3. Manbaga ishora taqiqi, shaxsiy ovoz va havola (foydalanuvchi qarori, 2026-11-15)

- **Manbaga ishora yozilmaydi**: «Falon manbada ... deyilgan», «... yozilgan», «O'quv qo'llanmada keltirilgan», «JSST ma'lumotlariga ko'ra», «Milliy protokolda ...», «Me'yorlarda ...», «Adabiyotda ...», «JSST tavsiyasiga ko'ra ...», «Davolash bayonnomasida ...» kabi gaplar taqiqlanadi (protokol, hujjat, qo'llanma, yo'riqnoma, bayonnoma, adabiyot, manba, me'yor, standart, atlas, darslik, taqdimot, JSST/xalqaro tavsiya nomi bilan). Fakt to'g'ridan-to'g'ri aytiladi va abzats oxirida `[n]` bilan tasdiqlanadi; manbaga ishora o'rniga «amaldagi tartib», «xalqaro tavsiya» kabi neytral ibora ishlatiladi. `check_outputs.py` bunday iboralarni XATO deb belgilaydi.
- **Shaxsiy fikr taqiqi (2026-11-16)**: matnda birinchi shaxsdagi shaxsiy fikr yozilmaydi. Taqiqlanadi: «men», «mening», «menga», «menimcha», «bizning», «biz», «-man» fe'l shakli («ekanman», «bilaman», «etaman», «chiqaman»), «-amiz/-emiz» fe'llari, egalik qo'shimchali «-shim», «-ligim» shakllari («tanlashimning sababi», «bilishim», «unutmasligim»), «mamlakatimiz» kabi egalik shakllari. Kirish va mavzu tavsifi «... bayon etiladi», «... ko'rib chiqiladi» shaklida yoziladi («Mavzuda ... bayon etiladi»). Shaxsiy kuzatuv, kundalik ish yoki «men uchun» kabi iboralar yozilmaydi; matn ilmiy maqola ohangida bo'ladi. `check_outputs.py` bu shakllarni XATO deb belgilaydi.
- **Rol**: matn parazitologiya bo'yicha oliy toifali shifokor nomidan yozilgan bo'lsa ham, rol shaxsiy ovozga aylanmaydi; ma'lumot manbalar asosida ilmiy maqola sifatida bayon etiladi.
- **Havola**: faqat `[n]` ko'rinishida, abzats oxirida birlashtirilgan (`... [1, 3].`). Manba nomi matn ichida yozilmaydi.
- **Adabiyotlar**: har bir yozuvda muallif (yoki tashkilot), nom, nashr va **yil** bo'lishi shart; yil ro'yxat yozuvining oxirida turadi. Yil faylda bo'lmasa, o'ylab topilmaydi.
- Bo'lim sarlavhalari neytral bo'lsin («Amaliy ahamiyati», «Profilaktika»); manbaga ishora qiluvchi sarlavha yozilmaydi.

## 3.4. Manbalar farqi: bittasi qoldiriladi (foydalanuvchi qarori, 2026-11-17)

Manbalar bir-biriga zid bo'lganda matnda ikkala variant bayon qilinmaydi, faqat bittasi qoldiriladi: kuchlisi va yangisi.
- **Kuch darajasi**: A = milliy normativ hujjatlar (buyruq, davolash tartibi, protokol), rasmiy uslubiy qo'llanmalar va JSST nashrlari; B = darslik, monografiya, hakamlanadigan maqola; C = taqdimot, ma'ruza, o'quv materiali, yili noma'lum material.
- **Tanlov tartibi**: C hech qachon A yoki B ga qarshi tanlanmaydi. A va B orasida yangisi tanlanadi. Bir daraja va bir yil bo'lsa, O'zbekistonga tegishli (milliy) manba tanlanadi.
- Qoldirilmagan manbaning faqat zid ma'lumoti olib tashlanadi; zid bo'lmagan ma'lumot va havolalar saqlanadi. Hech bir gapda foydalanilmay qolgan manba adabiyotlardan chiqariladi va havolalar qayta raqamlanadi.
- «Farqlar» bo'limlari qayta nomlanadi yoki olib tashlanadi; matnda «bir tavsifda ..., boshqasida ...» shakli qolmaydi.
- **Matn talablari**: Kirish va Xulosada «manbalar o'rtasidagi farqlar ko'rsatiladi» kabi va'dalar yozilmaydi. «Ikki asar», «asarlar o'rtasidagi farq», «turli tadqiqotlarda farq qiladi» kabi iboralar taqiqlanadi. Tanlangan ma'lumot to'g'ridan-to'g'ri aytiladi (3.3-bo'lim), oxirida faqat `[n]`.
- **Ish tartibi**: (1) spec'dagi har bir adabiyot darajasi (A/B/C) va yili aniqlanadi; (2) zid gaplar qidiriladi («farq», «turlicha», «ikki asar», raqamlar mos kelmasligi); (3) 3.4 tartibi bo'yicha bittasi tanlanadi, qoldirilmagani olib tashlanadi; (4) hamma o'zgarishdan keyin foydalanilmagan adabiyotlar chiqariladi va havolalar qayta raqamlanadi; (5) bir xil fakt boshqa mavzularda ham uchrasa, qiymati bir xil bo'lishi tekshiriladi (masalan, gelmint turlari soni, chivin turlari ro'yxati).
- **Manba nimani aytgani**: `_build\src_txt\NNN.txt` da asl manbaga ishora saqlangan bo'lsa, shundan aniqlanadi; aniqlab bo'lmasa, tanlov qilinmaydi, gap tasdiqlanmagan ma'lumotlar ro'yxatiga (`_build/tasdiqlanmagan.md`) yoziladi.
- **Hisobotda**: darajasi teng bo'lib, milliy manba tanlangan joylar (tie-break) alohida ko'rsatiladi. `check_outputs.py` «Bir tavsifda», «ikki asar», «asarlar o'rtasidagi farq» iboralarini XATO deb belgilaydi.

## 4. Spec yozish va fayl qurish

Har bir mavzu uchun `<manba-papkasi>\_build\specs\NNN.json` yozing:

```json
{
  "number": 1,
  "title": "1-mavzu. Mavzu nomi",
  "sections": [
    { "heading": "Kirish", "content": [
        "Paragraf matni, fakt [1].",
        { "ul": ["sanalmagan band", "yana band"] },
        { "ol": ["birinchi qadam", "ikkinchi qadam"] }
    ]},
    { "heading": "Xulosa", "content": ["Xulosa matni [2]."] }
  ],
  "references": [
    "Muallif. Kitob nomi. Nashriyot, 2020.",
    "JSST. Qo'llanma nomi. Jeneva, 2021. DOI: ... [tasdiqlanmagan]"
  ]
}
```

Qurish (bir marta `docx` paketini o'rnating; loyihaga qo'shilmaydi):

```bash
npm install --prefix "%TEMP%\topic-docx-deps" docx
```

```bash
node "C:\Users\xkomilov\.claude\skills\topic-docx-packager\scripts\build_docx.js" --dir "<manba-papkasi>\_build\specs" "<natija-papkasi>"
```

- Minimumdan kam mavzu yozilmaydi (`QISQA` xabari). Uni spec'da to'ldirib, qayta qurish kerak.
- `--min` bilan minimumni o'zgartirish mumkin (faqat foydalanuvchi so'ragan holda).
- Ogohlantirishlar (`[n] adabiyotlarda yo'q`, `ishlatilmagan manba`) — tuzating.
- Fayl Word'da ochiq bo'lsa `YOZILMADI` chiqadi: yopib qayta ishga tushiring.

## 5. Tekshirish

Linux/macOS (PowerShell yo'q bo'lsa):

```bash
python3 <skill>/scripts/check_outputs.py --dir "<natija-papkasi>" --min 800 --expected <mavzular soni>
NODE_PATH=<ish>/deps/node_modules node <skill>/scripts/build_docx.js --dir <specs> <natija> --min 800   # docx paketi: npm install --prefix <ish>/deps docx
```

Windows:

```
powershell -ExecutionPolicy Bypass -File "C:\Users\xkomilov\.claude\skills\topic-docx-packager\scripts\check_outputs.ps1" -Dir "<natija-papkasi>" -Min 800 -Expected <mavzular soni>
```

Holat ustuni: `OK`, `OGOH` (ogohlantirish), `XATO` (tuzatish shart). Oxirgi qator "XATO yo'q" bo'lishi kerak. Natija `XATO` bo'lsa, faqat o'sha faylni tuzating va qayta qurib tekshiring.

## 6. Seans o'zgartirishlari

Foydalanuvchi sessiya davomida kiritgan **har bir** o'zgartirishni (matn, tartib, manba, format, papka, hajm qoidasi) darhol `references\changelog.md` ga sana va qisqa tavsif bilan yozing. Agar o'zgartirish skill qoidasiga ta'sir qilsa, SKILL.md ni ham yangilang. O'zgartirishlarni xotirada saqlashga tayanmang.

## 7. Yakuniy hisobot (o'zbekcha)

1. Yaratilgan fayllar soni va ro'yxati; manbadagi mavzular soni bilan solishtirish.
2. So'z soni: eng kichik va eng katta; minimumdan kam fayl yo'q.
3. **Tasdiqlanmagan faktlar** ro'yxati: fayl, bo'lim, fakt.
4. **Farq qiladigan joylar**: rasmiy manbalar bir-biridan qayerda farq qiladi (raqam, muddat, me'yor).
5. Ochiq qolgan joylar va qo'lda tekshirish kerak bo'lganlar.
6. Seans o'zgartirishlari (`changelog.md` ga havola).

Hisobotda ko'rsatilgan har bir raqam tekshiruv natijasiga asoslangan bo'lsin. Tekshirilmagan narsani tekshirilgan deb yozmang.

## Eslatmalar

- `check_outputs.ps1` builder'dan mustaqil tekshiradi; ikkalasini ham ishga tushiring.
- Mavzular soni katta bo'lsa (50+), partiya boshiga qisqa holat yozing: "N/M tayyor, qolgani: ...".
- Builder ma'lumotlarni ko'rsatilgan `number` bo'yicha nomlaydi; bir xil raqamli ikki spec bo'lsa, oxirgisi ustiga yoziladi — shuni tekshiring.

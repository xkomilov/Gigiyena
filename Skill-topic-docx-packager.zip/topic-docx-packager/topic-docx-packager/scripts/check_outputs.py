#!/usr/bin/env python3
# topic-docx-packager: check_outputs.ps1 ning Python (Linux/macOS) varianti, builder'dan mustaqil tekshiruv.
#   python3 check_outputs.py --dir <natija-papkasi> [--min 800] [--expected N]
# Tekshiruvlar: nom (NNN.docx), "Foydalanilgan adabiyotlar" bo'limi, asosiy matn so'zlari (sarlavha va
# adabiyotlar hisobga kirmaydi), [n] havolalar va adabiyot raqamlari mosligi, apostroflar,
# SKILL.md 3.2/3.3 taqiqlari (manbaga ishora, taqiqlangan bo'lim, birinchi shaxs).
import argparse, html, os, re, sys, zipfile

APOS = re.compile('[\u2019\u2018\u02BB\u02BC\u00B4`]')
SENT_SPLIT = re.compile(r'(?<=[.!?])\s+')

# Bo'lim va ibora taqiqlari (SKILL.md 3.2)
BANNED_SECTIONS = [
    (re.compile(r"Tasdiqlanmagan ma'lumotlar|Laboratoriya xodimi uchun|Laborant uchun|Laborant vazifalari|"
                r"Takrorlash uchun savollar|Imtihon uchun|Savolga (javob|qanday|halol)|Klinik misol|Tashxis misoli|"
                r"Amaliy misol|Shartli hisoblash misoli|Eslatma\b", re.I), "bo'lim/ibora"),
    (re.compile(r"\bimtihon(da|ga|i)?\b|\bsavolga javob|\b(bu|ushbu) savol(da)?\b|savol sarlavhasidagi|\besse(da|dagi|ga|ning)?\b", re.I),
     "repetitorlik iborasi"),
    # Foydalanuvchi qarori 2026-11-17: «Bu esa ...» jumlasi taqiqlanadi (har qanday joyda).
    (re.compile(r"\bbu(ni|lar|nda|ning|dan)? esa\b", re.I), "«Bu esa» iborasi"),
    # Foydalanuvchi qarori 2026-11-17 (SKILL.md 3.4): manbalar farqi bayon qilinmaydi, bittasi qoldiriladi.
    (re.compile(r"\bBir tavsifda\b|\bikki asar\w*|\bikkala asar\b|\basarlar (?:o'rtasidagi|orasidagi) (?:raqamli )?farq\w*", re.I),
     "manbalar farqi iborasi"),
]

# Manba nomi gap ichida manbaga ishora sifatida kelsa taqiqlanadi (SKILL.md 3.3).
# «infeksiya manbai» kabi tibbiy atama ishora hisoblanmaydi: faqat manbalar, manbada, manbaga kabi shakllar.
SOURCE_WORD = re.compile(
    r"\b(manba(lar\w*|da|ga|dan)|qo'llanma\w*|yo'riqnoma\w*|darslik\w*|taqdimot\w*|protokol\w*|bayonnoma\w*|"
    r"adabiyot\w*|me'yor\w*|atlas\w*|vikipediya\w*|hujjat\w*|JSST\w*|standart\w*)\b", re.I)
ATTRIBUTION = re.compile(
    r"yozilgan|deyilgan|keltirilgan|ko'rsatilgan|qayd etil|ko'ra\b|bayon etil|ta'rif|tavsiya|"
    r"ta'kidla|aytilgan|sanalgan|belgilangan", re.I)
SOURCE_PHRASE = re.compile(r"ma'lumot\w*(ga|iga|lariga) ko'ra|deyilgan|keltirilgan", re.I)

# Birinchi shaxs (SKILL.md 3.3, 2026-11-16). Faqat kichik harfli so'zlar tekshiriladi,
# shuning uchun Andaman, Neman, ISEMIZ kabi atoqli otlar xato bermaydi.
FIRST_PERSON = re.compile(r"\b(men|mening|menga|menimcha|bizning|biz)\b", re.I)
FIRST_PERSON_SUFFIX = re.compile(
    r"\b(ekanman|bilaman|etaman|chiqaman|[a-z']+(aman|eman|iman|oman|yman)|[a-z']+(amiz|emiz)|"
    r"[a-z']+(shim|shimning|shimni|shimga|ligim))\b")

CITE = re.compile(r'\[(\d+(?:\s*[,;\u2013-]\s*\d+)*)\]')


def paras(path):
    x = zipfile.ZipFile(path).read('word/document.xml').decode('utf8')
    out = []
    for p in re.findall(r'<w:p[ >].*?</w:p>', x, re.S):
        p = p.replace('<w:tab/>', '\t')
        t = html.unescape(''.join(re.findall(r'<w:t(?: [^>]*)?>(.*?)</w:t>', p, re.S))).strip()
        if t:
            out.append(t)
    return out


def flagged_sentences(text):
    """Manbaga ishora bo'lgan gaplar ro'yxati."""
    out = []
    for s in SENT_SPLIT.split(text):
        if (SOURCE_WORD.search(s) and ATTRIBUTION.search(s)) or SOURCE_PHRASE.search(s):
            out.append(s.strip())
    return out


def violations(text):
    """Matndagi taqiqlangan parchalarni (label, parcha) ro'yxati bilan qaytaradi."""
    found = []
    for rx, label in BANNED_SECTIONS:
        for m in rx.finditer(text):
            found.append((label, m.group(0)))
    for s in flagged_sentences(text):
        found.append(("manbaga ishora", s[:90]))
    for m in FIRST_PERSON.finditer(text):
        found.append(("shaxsiy fikr (birinchi shaxs)", m.group(0)))
    for m in FIRST_PERSON_SUFFIX.finditer(text):
        found.append(("shaxsiy fikr (birinchi shaxs fe'l/egalik)", m.group(0)))
    return found


def check(path, mn):
    notes = []
    name = os.path.basename(path)
    if not re.match(r'^\d{3}\.docx$', name):
        notes.append('nom NNN.docx emas')
    try:
        ps = paras(path)
    except Exception as e:
        return name, '', 0, 0, 'XATO', f"o'qilmadi: {e}"
    ri = next((i for i in range(1, len(ps)) if ps[i].startswith('Foydalanilgan adabiyotlar')), -1)
    if ri < 0:
        notes.append("'Foydalanilgan adabiyotlar' bo'limi yo'q")
        body, refs = ps[1:], []
    else:
        body, refs = ps[1:ri], ps[ri + 1:]
    words = sum(len(l.split()) for l in body)
    nref = len([r for r in refs if re.match(r'^\[\d+\]', r)])
    text = ' '.join(body)
    if words < mn:
        notes.append(f"so'z {words} < {mn}")
    if nref == 0:
        notes.append("adabiyot yozuvlari yo'q")
    if APOS.search(text):
        notes.append("noto'g'ri apostrof")
    for label, frag in violations(text):
        notes.append(f"taqiqlangan {label}: «{frag}»")
    cited = set()
    for m in CITE.finditer(text):
        for tk in re.split(r'\s*[,;]\s*', m.group(1)):
            r = [int(v) for v in re.split(r'\s*[\u2013-]\s*', tk)]
            cited.update(range(r[0], r[1] + 1) if len(r) == 2 else r)
    for c in sorted(cited):
        if c < 1 or c > nref:
            notes.append(f"[{c}] adabiyotda yo'q")
    unused = [k for k in range(1, nref + 1) if k not in cited]
    if unused:
        notes.append('ishlatilmagan manba: ' + ', '.join(map(str, unused)))
    hard = [n for n in notes if not n.startswith('ishlatilmagan')]
    status = 'XATO' if hard else ('OGOH' if notes else 'OK')
    return name, (ps[0][:40] if ps else ''), words, nref, status, '; '.join(notes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--min', type=int, default=800)
    ap.add_argument('--expected', type=int, default=0)
    a = ap.parse_args()
    files = sorted(f for f in os.listdir(a.dir) if f.endswith('.docx') and not f.startswith('~$'))
    rows = [check(os.path.join(a.dir, f), a.min) for f in files]
    problems = sum(1 for r in rows if r[4] == 'XATO')
    for r in rows:
        print(f'{r[0]}  {r[2]:5d} so\'z  {r[3]:3d} manba  {r[4]:4s}  {r[1]}  {r[5]}')
    print(f'Jami fayl: {len(files)}')
    if rows:
        print(f"So'z: min {min(r[2] for r in rows)}, max {max(r[2] for r in rows)}")
    if a.expected:
        if len(files) == a.expected:
            print(f'Kutilgan {a.expected} ta fayl: mos')
        else:
            print(f'DIQQAT: kutilgan {a.expected}, mavjud {len(files)}')
            problems += 1
    if problems:
        print(f'Xatolar bor: {problems}')
        sys.exit(1)
    print("Barcha tekshiruvlar o'tdi (XATO yo'q).")


if __name__ == '__main__':
    main()
